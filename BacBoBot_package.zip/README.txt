
Bac Bo Analysis & Suggestion Bot
=================================

**O que é**  
Um pequeno aplicativo que analisa os resultados do Bac Bo e sugere a próxima aposta,
combinando quatro estratégias (Martingale, Anti‑padrão, Repetição e Empates raros).
O programa NÃO clica nem aposta sozinho — ele apenas mostra a recomendação.

**Pré‑requisitos**  
- Windows 64‑bits  
- Python 3.10+ (será instalado automaticamente pelo instalador)  

**Como usar**  
1. Extraia todos os arquivos do ZIP.  
2. Clique em `BacBoBot.exe` para abrir o bot.  
   (Se for a primeira execução, pode demorar alguns segundos.)  
3. No terminal que abrir, digite os resultados do Bac Bo:  
   - `J` para Jogador  
   - `B` para Banqueiro  
   - `E` para Empate  
   - `sair` para encerrar  
4. O bot mostrará a **próxima aposta sugerida** e o valor da stake.  
5. Você decide se segue ou não.  

**Ajustes**  
- Para alterar o valor inicial da aposta, alvo de lucro, etc., edite `bacbo_bot.py`
  nas variáveis `INITIAL_STAKE`, `PROFIT_TARGET`, `LOSS_LIMIT`, `TIE_THRESHOLD`.  
- Se sabe usar Python, pode rodar direto com `python bacbo_bot.py`.  

**Compilando manualmente (opcional)**  
Se preferir gerar seu próprio `.exe`, instale as dependências e rode:  
    pip install pyinstaller  
    pyinstaller --onefile bacbo_bot.py  

**Aviso**  
Este software não garante lucro. Use por sua conta e risco.  
